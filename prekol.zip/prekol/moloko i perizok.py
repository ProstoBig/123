import sys
from math import ceil
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit

class CountUnderweight(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Count Underweight")

        self.n_label = QLabel("Кількість студентів:")
        self.n_textbox = QLineEdit()
        
        self.nigr_label = QLabel("Маса студентів:")
        self.nigr_textbox = QTextEdit()
        
        self.result_label = QLabel("Результат:")
        self.result_textbox = QLineEdit()
        self.result_textbox.setReadOnly(True)
        
        self.calculate_button = QPushButton("Обчислити")
        self.calculate_button.clicked.connect(self.calculate)
        
        layout = QVBoxLayout()
        layout.addWidget(self.n_label)
        layout.addWidget(self.n_textbox)
        layout.addWidget(self.nigr_label)
        layout.addWidget(self.nigr_textbox)
        layout.addWidget(self.result_label)
        layout.addWidget(self.result_textbox)
        layout.addWidget(self.calculate_button)
        
        self.setLayout(layout)
    
    def calculate(self):
        try:
            n = int(self.n_textbox.text())
            nigr = list(map(float, self.nigr_textbox.toPlainText().split()))
            
            uch = 0
            for weight in nigr:
                if weight < 30.0:
                    uch += 1
            
            res = ceil(200.0 * uch / 900)
            self.result_textbox.setText("{:.0f} {}".format(res, uch))
        except ValueError:
            self.result_textbox.setText("Неправильний формат вводу")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    counter = CountUnderweight()
    counter.show()
    sys.exit(app.exec())
