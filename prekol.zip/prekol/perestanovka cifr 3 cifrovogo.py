import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyQt6 Program")
        
        self.input_label = QLabel("Введіть число:")
        self.input_textbox = QLineEdit()
        
        self.output_label = QLabel("Результат:")
        self.output_textbox = QLineEdit()
        self.output_textbox.setReadOnly(True)
        
        self.calculate_button = QPushButton("Обчислити")
        self.calculate_button.clicked.connect(self.calculate)
        
        layout = QVBoxLayout()
        layout.addWidget(self.input_label)
        layout.addWidget(self.input_textbox)
        layout.addWidget(self.output_label)
        layout.addWidget(self.output_textbox)
        layout.addWidget(self.calculate_button)
        
        self.setLayout(layout)
    
    def calculate(self):
        try:
            n = int(self.input_textbox.text())
            q = n // 100
            w = (n % 100) // 10
            e = n % 10
            result = e * 100 + w * 10 + q
            self.output_textbox.setText(str(result))
        except ValueError:
            self.output_textbox.setText("Неправильний формат числа")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())