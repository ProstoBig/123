import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

class CheckCondition(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Check Condition")

        self.a_label = QLabel("a:")
        self.a_textbox = QLineEdit()
        
        self.b_label = QLabel("b:")
        self.b_textbox = QLineEdit()
        
        self.c_label = QLabel("c:")
        self.c_textbox = QLineEdit()
        
        self.x_label = QLabel("x:")
        self.x_textbox = QLineEdit()
        
        self.y_label = QLabel("y:")
        self.y_textbox = QLineEdit()
        
        self.result_label = QLabel("Результат:")
        self.result_textbox = QLineEdit()
        self.result_textbox.setReadOnly(True)
        
        self.check_button = QPushButton("Перевірити")
        self.check_button.clicked.connect(self.check_condition)
        
        layout = QVBoxLayout()
        layout.addWidget(self.a_label)
        layout.addWidget(self.a_textbox)
        layout.addWidget(self.b_label)
        layout.addWidget(self.b_textbox)
        layout.addWidget(self.c_label)
        layout.addWidget(self.c_textbox)
        layout.addWidget(self.x_label)
        layout.addWidget(self.x_textbox)
        layout.addWidget(self.y_label)
        layout.addWidget(self.y_textbox)
        layout.addWidget(self.result_label)
        layout.addWidget(self.result_textbox)
        layout.addWidget(self.check_button)
        
        self.setLayout(layout)
    
    def check_condition(self):
        try:
            a = int(self.a_textbox.text())
            b = int(self.b_textbox.text())
            c = int(self.c_textbox.text())
            x = int(self.x_textbox.text())
            y = int(self.y_textbox.text())
            
            if (a <= x and b <= y) or (a <= y and b <= x) or (a <= x and c <= y) or \
               (a <= y and c <= x) or (b <= x and c <= y) or (b <= y and c <= x):
                self.result_textbox.setText("YES")
            else:
                self.result_textbox.setText("NO")
        except ValueError:
            self.result_textbox.setText("Неправильний формат вводу")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    checker = CheckCondition()
    checker.show()
    sys.exit(app.exec())
